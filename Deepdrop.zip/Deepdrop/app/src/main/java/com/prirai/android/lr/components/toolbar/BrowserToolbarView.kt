package com.prirai.android.lr.components.toolbar

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.annotation.VisibleForTesting
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.prirai.android.lr.R
import com.prirai.android.lr.ext.components
import com.prirai.android.lr.preferences.UserPreferences
import com.prirai.android.lr.utils.ToolbarPopupWindow
import kotlinx.coroutines.ExperimentalCoroutinesApi
import mozilla.components.browser.state.selector.selectedTab
import mozilla.components.browser.state.state.CustomTabSessionState
import mozilla.components.browser.toolbar.BrowserToolbar
import mozilla.components.browser.toolbar.display.DisplayToolbar
import mozilla.components.support.ktx.util.URLStringUtils.toDisplayUrl
import mozilla.components.ui.widgets.behavior.EngineViewScrollingGesturesBehavior
import java.lang.ref.WeakReference
import androidx.core.net.toUri

interface BrowserToolbarViewInteractor {
    fun onBrowserToolbarPaste(text: String)
    fun onBrowserToolbarPasteAndGo(text: String)
    fun onBrowserToolbarClicked()
    fun onBrowserToolbarMenuItemTapped(item: ToolbarMenu.Item)
    fun onTabCounterClicked()
    fun onScrolled(offset: Int)
}

@ExperimentalCoroutinesApi
class BrowserToolbarView(
    private val container: ViewGroup,
    private val toolbarPosition: ToolbarPosition,
    private val interactor: BrowserToolbarViewInteractor,
    private val customTabSession: CustomTabSessionState?,
    private val lifecycleOwner: LifecycleOwner,
    private val engineView: mozilla.components.concept.engine.EngineView? = null
) {

    private val settings = UserPreferences(container.context)

    @LayoutRes
    private val toolbarLayout = when (settings.toolbarPosition) {
        ToolbarPosition.BOTTOM.ordinal -> R.layout.component_bottom_browser_toolbar
        else -> R.layout.component_browser_top_toolbar
    }

    private val layout = if (toolbarLayout == R.layout.component_bottom_browser_toolbar && container is CoordinatorLayout) {
        // For bottom toolbar, inflate without adding to container first, then add with proper params
        val inflatedView = LayoutInflater.from(container.context).inflate(toolbarLayout, null, false)
        val toolbarContainer = inflatedView.findViewById<View>(R.id.toolbarContainer) ?: inflatedView
        
        // Create proper CoordinatorLayout.LayoutParams
        val layoutParams = CoordinatorLayout.LayoutParams(
            CoordinatorLayout.LayoutParams.MATCH_PARENT,
            CoordinatorLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = android.view.Gravity.BOTTOM
        }
        
        container.addView(toolbarContainer, layoutParams)
        
        inflatedView
    } else {
        // For other layouts, use normal inflation
        LayoutInflater.from(container.context).inflate(toolbarLayout, container, true)
    }

    @VisibleForTesting
    internal var view: BrowserToolbar = layout
        .findViewById(R.id.toolbar)

    // Get the actual container for bottom toolbar
    private val toolbarContainer: View? = if (toolbarLayout == R.layout.component_bottom_browser_toolbar) {
        val container = layout.findViewById<View>(R.id.toolbarContainer)
        container ?: layout
    } else null

    val toolbarIntegration: ToolbarIntegration

    init {
        view.display.setOnUrlLongClickListener {
            ToolbarPopupWindow.show(
                WeakReference(view),
                customTabSession?.id,
                interactor::onBrowserToolbarPasteAndGo,
                interactor::onBrowserToolbarPaste
            )
            true
        }

        with(container.context) {
            val isPinningSupported = androidx.core.content.pm.ShortcutManagerCompat.isRequestPinShortcutSupported(this)

            view.apply {
                setToolbarBehavior()

                // Match Fenix's BrowserToolbarView: elevate the toolbar by
                // browser_fragment_toolbar_elevation (16dp) so it casts a
                // shadow over the EngineView, and let the AC display toolbar
                // draw the inner URL pill via display.setUrlBackground(...)
                // pointing at the same rounded ?attr/colorSurfaceContainerHigh
                // shape Fenix uses (search_url_background). This is the single
                // frictionless integration point the upstream toolbar exposes;
                // any custom padding/margin overrides in the layout XML fight
                // AC's baked mozac_browser_toolbar_displaytoolbar.xml.
                elevation = resources.getDimension(R.dimen.browser_fragment_toolbar_elevation)

                display.setUrlBackground(
                    androidx.appcompat.content.res.AppCompatResources.getDrawable(
                        container.context,
                        R.drawable.toolbar_background
                    )
                )

                // Inset the URL pill 12dp on each side. LR does not populate
                // the navigation-actions or browser-actions containers on the
                // address bar, so AC's ActionContainer collapses each of them
                // to View.GONE, and the URL background ImageView pins flush
                // against the parent edges (rounded corners invisible).
                // setUrlBackgroundMargins is AC's first-class API for exactly
                // this case: it applies layout_goneMarginStart / goneMarginEnd
                // to the URL background, so ConstraintLayout inserts the
                // requested inset only when the neighbouring action containers
                // are GONE. The progress bar keeps its own edge-to-edge
                // constraint (constraintStart/End="parent"), so this does not
                // shorten the loading indicator.
                val pillInsetPx = (12f * resources.displayMetrics.density).toInt()
                display.setUrlBackgroundMargins(
                    mozilla.components.browser.toolbar.display.DisplayToolbar.DisplayMargins(
                        goneStartMargin = pillInsetPx,
                        goneEndMargin = pillInsetPx,
                    )
                )

                display.onUrlClicked = {
                    interactor.onBrowserToolbarClicked()
                    false
                }

                display.progressGravity = when (toolbarPosition) {
                    ToolbarPosition.BOTTOM -> DisplayToolbar.Gravity.TOP
                    ToolbarPosition.TOP -> DisplayToolbar.Gravity.BOTTOM
                }

                val primaryTextColor = ContextCompat.getColor(
                    container.context,
                    R.color.primary_icon
                )
                val secondaryTextColor = ContextCompat.getColor(
                    container.context,
                    R.color.secondary_icon
                )
                val separatorColor = ContextCompat.getColor(
                    container.context,
                    R.color.primary_icon
                )

                display.urlFormatter =
                    if (UserPreferences(context).showUrlProtocol) {
                            url -> url
                    } else {
                            url -> smartUrlDisplay(url)
                    }

                display.colors = display.colors.copy(
                    text = primaryTextColor,
                    siteInfoIconSecure = primaryTextColor,
                    siteInfoIconInsecure = primaryTextColor,
                    menu = primaryTextColor,
                    hint = secondaryTextColor,
                    separator = separatorColor,
                    trackingProtection = primaryTextColor
                )


                display.hint = context.getString(R.string.search)
            }

            val menuToolbar: ToolbarMenu
            BrowserMenu(
                context = this,
                store = components.store,
                onItemTapped = {
                    it.performHapticIfNeeded(view)
                    interactor.onBrowserToolbarMenuItemTapped(it)
                },
                lifecycleOwner = lifecycleOwner,
                isPinningSupported = isPinningSupported,
                shouldReverseItems = settings.toolbarPosition == ToolbarPosition.TOP.ordinal
            ).also { menuToolbar = it }

            view.display.setMenuDismissAction {
                view.invalidateActions()
            }

            toolbarIntegration = DefaultToolbarIntegration(
                    this,
                    view,
                    menuToolbar,
                    components.historyStorage,
                    lifecycleOwner,
                    sessionId = null,
                    isPrivate = components.store.state.selectedTab?.content?.private ?: false,
                    interactor = interactor,
                    engine = components.engine
                )
        }
    }

    fun expand() {
        val targetView = if (toolbarLayout == R.layout.component_bottom_browser_toolbar) {
            toolbarContainer ?: layout
        } else {
            view
        }
        
        (targetView.layoutParams as? CoordinatorLayout.LayoutParams)?.apply {
            (behavior as? EngineViewScrollingGesturesBehavior)?.forceExpand()
        }
    }

    fun collapse() {
        val targetView = if (toolbarLayout == R.layout.component_bottom_browser_toolbar) {
            toolbarContainer ?: layout
        } else {
            view
        }
        
        (targetView.layoutParams as? CoordinatorLayout.LayoutParams)?.apply {
            (behavior as? EngineViewScrollingGesturesBehavior)?.forceCollapse()
        }
    }

    /**
     * Pins the address bar to a fixed position - it never scrolls off-screen.
     *
     * The address bar is always the user's one guaranteed anchor to tap into
     * search, see the URL, and tap the chevron to toggle minimal state.
     * Previously this installed AC's `EngineViewScrollingGesturesBehavior`
     * which translated the whole toolbar off-screen 1:1 with page scroll;
     * that was removed in favour of a pinned address bar. Post-v0.5.14 the
     * scroll-driven minimal toggle was also removed - the chevron button is
     * the only remaining input (see ModernScrollBehavior kdoc).
     *
     * The @param is kept for source compatibility with existing call sites
     * but no longer influences behavior.
     */
    fun setToolbarBehavior(shouldDisableScroll: Boolean = false) {
        expandToolbarAndMakeItFixed()
    }

    @VisibleForTesting
    internal fun expandToolbarAndMakeItFixed() {
        expand()
        // Remove any pre-existing scroll behavior from the container so the
        // address bar stays pinned to its edge. All page-scroll driven hiding
        // is now the responsibility of UnifiedToolbar's minimal state.
        val targetView = if (toolbarLayout == R.layout.component_bottom_browser_toolbar) {
            toolbarContainer ?: layout
        } else {
            view
        }

        (targetView.layoutParams as? CoordinatorLayout.LayoutParams)?.apply {
            behavior = null
        }
    }

    private fun ToolbarMenu.Item.performHapticIfNeeded(view: View) {
        if (this is ToolbarMenu.Item.Reload && this.bypassCache ||
            this is ToolbarMenu.Item.Back && this.viewHistory ||
            this is ToolbarMenu.Item.Forward && this.viewHistory
        ) {
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
    }

    /**
     * Smart URL display that shows base domain + shortened path
     * Example: https://en.wikipedia.org/wiki/Sarojini_Naidu -> en.wikipedia.org/w/Sarojini_Naidu
     */
    private fun smartUrlDisplay(url: CharSequence): CharSequence {
        return try {
            val uri = url.toString().toUri()
            val host = uri.host ?: return toDisplayUrl(url)
            val path = uri.path ?: return host
            
            // Remove protocol and www prefix for display
            val cleanHost = host.removePrefix("www.")
            
            if (path == "/" || path.isEmpty()) {
                return cleanHost
            }
            
            // Smart path shortening logic: abbreviate path segments to first letter
            val pathSegments = path.split("/").filter { it.isNotEmpty() }
            
            when {
                // Handle Wikipedia URLs: /wiki/Article_Name -> /w/Article_Name
                pathSegments.size >= 2 && pathSegments[0] == "wiki" -> {
                    "$cleanHost/w/${pathSegments[1]}"
                }
                // Handle paths with 2 or more segments: abbreviate middle segments to first letter
                pathSegments.size >= 2 -> {
                    val abbreviatedSegments = mutableListOf<String>()
                    
                    // First segment: abbreviate to first letter
                    abbreviatedSegments.add(pathSegments[0].take(1))
                    
                    // Middle segments: abbreviate to first letter 
                    for (i in 1 until pathSegments.size - 1) {
                        abbreviatedSegments.add(pathSegments[i].take(1))
                    }
                    
                    // Last segment: keep full name
                    abbreviatedSegments.add(pathSegments.last())
                    
                    "$cleanHost/${abbreviatedSegments.joinToString("/")}"
                }
                // Show full path for single segment
                else -> {
                    "$cleanHost$path"
                }
            }
        } catch (_: Exception) {
            // Fallback to original toDisplayUrl function
            toDisplayUrl(url)
        }
    }
}
