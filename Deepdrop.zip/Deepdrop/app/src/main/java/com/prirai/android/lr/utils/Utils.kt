package com.prirai.android.lr.utils

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.TypedValue
import com.prirai.android.lr.R
import androidx.core.graphics.createBitmap


/**
 * Stateless helpers. Was previously an `open class` that every callsite was
 * instantiating as `Utils()` to reach these two methods - a fresh object per
 * call for no state. Converted to a Kotlin `object` singleton so all callers
 * share the one instance (`Utils.isTablet(...)` / `Utils.createImage(...)`).
 */
object Utils {

    /**
     * Generates letter bitmap in style of Mozac [DefaultIconGenerator] using first letter of string instead of URL
     */
    fun createImage(context: Context, name: String): Bitmap {
        val size = context.resources.getDimension(R.dimen.mozac_browser_icons_size_default)
        val sizePx = size.toInt()

        val bitmap = createBitmap(sizePx, sizePx)
        val canvas = Canvas(bitmap)

        val backgroundColor = Color.LTGRAY

        val paint = Paint()
        paint.color = backgroundColor

        val sizeRect = RectF(0f, 0f, size, size)
        val cornerRadius = context.resources.getDimension(R.dimen.mozac_browser_icons_generator_default_corner_radius)
        canvas.drawRoundRect(sizeRect, cornerRadius, cornerRadius, paint)

        val character = name.first().toString()

        // The text size is calculated dynamically based on the target icon size (1/8th). For an icon
        // size of 112dp we'd use a text size of 14dp (112 / 8).
        val textSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                size * 1 / 8f,
                context.resources.displayMetrics
        )

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = textSize
        paint.isAntiAlias = true

        canvas.drawText(
                character,
                canvas.width / 2f,
                (canvas.height / 2f) - ((paint.descent() + paint.ascent()) / 2f),
                paint
        )

        return bitmap
    }

    fun isTablet(context: Context): Boolean {
        return ((context.resources.configuration.screenLayout
                and Configuration.SCREENLAYOUT_SIZE_MASK)
                >= Configuration.SCREENLAYOUT_SIZE_LARGE)
    }
}